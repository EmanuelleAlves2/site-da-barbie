import { Text, View, StyleSheet, Image, Button, Alert } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Button
      title= 'comprar ingresso'
      onPress={()=>Alert.alert('golpe')}
      />
    </View>
 );
}